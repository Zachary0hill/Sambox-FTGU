# Integrations settings refactor: handoff spec

Repo: Sambox-FTGU (Next.js 15, Supabase)
Page: Workspace Settings > Integrations (`/admin/workspace`, Integrations tab, Super Admin only)
Scope: UI refactor only. No changes to server routes, Vault RPCs, RLS or provider modules.

## Goal

- Replace the stacked inline forms with a grid of integration cards.
- Click a card to open a modal.
- The modal shows only the required fields for a quick add.
- Everything else sits in a collapsed Advanced section inside the modal.
- Every card shows the provider's real logo.

## Where the current code lives

| File | What it does now | Change |
|---|---|---|
| `lib/integrations/registry.ts` | Provider catalogue: `PROVIDERS`, `GROUPS`, `AI_PROVIDERS`, fields | Add `logo` and `powers` to `ProviderDef` |
| `lib/studio/vals-admin.js` | `integCard(p)` (around line 458) builds card and field view models. `integGroups` (around line 521) | Split fields into quick add and advanced. Add filter, search, modal and advanced state |
| `components/studio/StudioView.jsx` | Renders `V.adm.ws.integGroups` (around line 1872) | Render the grid, toolbar and modal |

Keep these exactly as they work today:

- `A.saveIntegration(g, out)`
- `A.disconnectIntegration(g)`
- `A.syncIntegration(g)`
- `A.listModels(pid, key)` and the `queueModels` debounce
- `A.updateSettings({ ai_provider })` for the assistant pick
- `integDraft` per-provider drafts and `integBusy` busy states
- `keyNote`, `last_error`, `last_checked_at`, `last_synced_at` handling

## Design reference files

- `design/Main.dc.html`: full page with grid, toolbar and modal logic.
- `design/Modal-monday.dc.html`: modal open on monday.com, quick-add state.
- `design/Modal-openai.dc.html`: modal open on OpenAI, connected, Advanced expanded.
- `design/canvas.json`: canvas layout index. Ignore for implementation.
- Live canvas (owner access): https://claude.ai/code/artifact/25f6be7f-e74a-4575-af04-6e89203beb0f

How to read the `.dc.html` files:

- They are design-tool source, not production code. Do not import them.
- Inline `style="..."` values are the exact spacing, radius, size and color specs.
- `<sc-for list="{{x}}" as="y">` = `x.map((y) => ...)` in JSX.
- `<sc-if value="{{x}}">` = `{x && ...}` in JSX.
- `{{path}}` = a value from `renderVals()`. The `renderVals()` script at the bottom of `Main.dc.html` holds the full view-model logic: field split, advanced summary, pills, tabs, filters.
- Hard-coded hex values in the design map to the app's CSS variables (see Tokens). Use the variables so dark mode keeps working.

## Assets

Copy `public/integrations/` into the repo's `public/integrations/`.

| Provider id | File |
|---|---|
| anthropic | `/integrations/anthropic.svg` |
| openai | `/integrations/openai.svg` |
| gemini | `/integrations/gemini.svg` |
| monday | `/integrations/monday.png` |
| apify | `/integrations/apify.svg` |
| browserbase | `/integrations/browserbase.svg` |
| firecrawl | `/integrations/firecrawl.svg` |
| slack | `/integrations/slack.svg` |
| youtube | `/integrations/youtube.svg` |
| buffer | `/integrations/buffer.svg` |

Sources: svgl.app library (Claude, OpenAI, Gemini, Firecrawl, Slack, YouTube), simple-icons (Buffer), each company's site icon (monday.com, Apify, Browserbase).

Logo tile rule: the logo always sits on a white tile with a 1px border, in light and dark mode. The OpenAI and Buffer marks are black and need the white tile.

## Registry changes

Add to `ProviderDef`:

```ts
logo: string;      // '/integrations/<id>.svg' (monday: .png)
powers: string[];  // pages this integration feeds, shown as chips in Advanced
```

`powers` values:

| Provider | powers |
|---|---|
| anthropic, openai, gemini | `['Daily', 'Ideas & Research']` |
| monday | `['Projects', 'Settings']` |
| apify, browserbase | `['Ideas & Research']` |
| firecrawl | `['Daily', 'Ideas & Research']` |
| slack | `['Inbox']` |
| youtube | `['Content']` |
| buffer | `['Content', 'Inbox']` |

Do not add new flags for the field split. It is derived (next section).

## Field split rule

- Quick add = every field where `!f.optional && f.choices !== 'models'`.
- Advanced = every optional field plus the model field.
- Setup notes = the `help` text of the quick-add fields. These show in Advanced under "Where to find them", not under the inputs.
- "Get a key" link (`p.keyUrl`) sits on the label row of the first required secret field, right-aligned.

Result per provider:

| Provider | Quick add | Advanced |
|---|---|---|
| Claude | API key | Model, assistant switch |
| OpenAI | API key | Model, assistant switch |
| Gemini | API key | Model, assistant switch |
| monday.com | API token, Board ID | Status column ID, Status mapping, Job number column ID, setup notes, Sync |
| Apify | API token | Docs |
| Browserbase | API key, Project ID | Docs |
| Firecrawl | API key | Docs |
| Slack | Bot token | Signing secret, Channels to watch, setup notes, Sync |
| YouTube | API key, Channels | Setup notes, Sync |
| Buffer | API key | Setup notes, Sync |

The model field keeps its default (`defaultValue`) when Advanced stays closed, so save behavior does not change.

## Page layout

1. Page header: unchanged.
2. Settings sub-nav: unchanged. The Integrations item shows `{connected}/10` on the right.
3. Section intro row:
   - Left: h2 "Integrations" (`--font-title`, 22px, weight 900). Below it: "{n} of 10 integrations connected. Keys are stored encrypted. Only Super Admins can add, replace or remove them."
   - Right: "Use them in Automations" ghost button (existing action).
4. Toolbar row with a bottom border:
   - Filter tabs: All, Connected, Not connected. Each shows a count badge. `aria-pressed` on each. Active tab = inverted (ink background, white text).
   - Search input on the right, 300px max, search icon inside. Matches name, description and group.
5. Groups in `GROUPS` order. Each group: h3 title, description, "x of y connected" on the right. Hide a group when the filter or search leaves it empty.
6. Grid: `grid-template-columns: repeat(auto-fill, minmax(250px, 1fr))`, gap 16px.
7. Empty state when nothing matches: dashed border box, "No integrations match", "Clear the search or switch the filter to All."

## Card

The whole card is one `<button type="button">` that opens the modal. Inner elements are `<span>` (no block elements inside a button).

- Size: min-height 196px, padding 18px, radius 16px, 1px `--border`, `--surface` background.
- Hover: border darkens, soft shadow, 1px lift.
- Top row: 52px logo tile (radius 14px, logo 30px, `object-fit: contain`) on the left. Status pill on the right.
- Name (16px, 600). An "Assistant" badge (ink background, 11px) appears next to the name for the provider that runs the Daily assistant.
- Description (13px, muted, from the DB `g.description`).
- Footer with a top border:
  - Left: `keyNote` when connected ("Key ending NMEA · Checked Oct 21"). Otherwise "No key saved". One line, ellipsis.
  - Right: "Manage" (connected) or "Connect" (not connected), with a chevron.
- `aria-label`: "{name}, {status}. Open settings".

Status pill (rounded, 24px tall, 6px dot):

| State | Condition | Text | Colors |
|---|---|---|---|
| Connected | `status === 'connected'` and no `last_error` | Connected | `--green-ink` on a soft green |
| Needs attention | connected with `last_error` | Needs attention | `--red-ink` on a soft red |
| Not connected | anything else | Not connected | dark gray on `--chip` |

The design uses rounded pills. The current app uses square `hardBlock` chips. Rounded pills are the new direction for this page.

## Modal

Width 580px max, radius 20px, shadow `0 24px 64px rgba(0,0,0,.2)`. Backdrop `rgba(17,17,17,.45)`. Aligned to the top with 64px padding. Scrolls when tall.

Order:

1. Header: 60px logo tile, name (20px, 700), status pill, one-line description, 44px close button (X).
2. Error banner (new): when `last_error` is set, a red-ink note under the header. Keep the existing error text.
3. Quick add fields: label, input (46px, radius 12px, `--surface-2` fill). Secret inputs use `type="password"` and a monospace font. A saved secret shows the placeholder "Saved. Paste a new value to replace it".
4. Advanced toggle: a full-width `<button aria-expanded aria-controls="ig-adv">` with a chevron that rotates 90deg when open, the label "Advanced", and a right-aligned summary in muted text.
5. Advanced panel (collapsed by default):
   - Advanced fields. Label row: label, an "Optional" tag, and an "Encrypted" tag with a lock icon for secret fields. Help text sits under each field.
   - Model select. Disabled until a key is saved or pasted. Help: "Paste an API key to choose from the models it can use." Keep all the existing loading and error help strings.
   - "Where to find them": a `label: help` line for each quick-add field that has help.
   - AI only: a "Use for the Daily assistant" row with a switch (48x28, `aria-pressed`). Disabled until connected. Note text:
     - Active: "The Daily assistant answers with this model."
     - Another provider active: "The assistant uses {name} now. Turn on to switch."
     - Not connected: "Connect a key first."
   - `canSync` only: a Sync row with a "Sync now" button. Disabled until connected. Note: last synced time, or "Available after you connect."
   - "Powers" chips from `p.powers`.
   - Vault note with a shield icon: "Secrets go to Supabase Vault and never come back to the browser. Cards show the last 4 characters only. Keys are checked with a live call on save."
   - "API docs" external link (`p.docs`).
6. Footer with a top border:
   - Left: "Disconnect" as a red-ink text button, connected only.
   - Right: "Cancel" ghost button, then the primary button: "Save and connect" / "Save changes" / "Checking…" while busy.

Advanced summary text (comma-joined, first letter capitalized), built in this order:

- "model" if a model field exists
- "assistant" if AI
- "{n} optional field(s)" if any
- "sync" if `canSync`
- "setup notes" if any quick-add help exists
- "docs" always

Example: "3 optional fields, sync, setup notes, docs".

## Behavior

- Open: card click. Store the open provider id in state (`integOpen`). Reset Advanced to collapsed on every open (`integAdv: false`).
- Close: X button, Cancel, backdrop click, Escape key. Return focus to the card that opened the modal.
- Focus: trap focus inside the dialog. Initial focus on the first quick-add input.
- Save: call the existing `save()`. On success, close the modal and keep the card status current. On failure, keep the modal open, show the error banner, and keep the drafts.
- Model list: fetch with the existing `queueModels` when Advanced is open or a full-length key is pasted.
- Assistant switch: `A.updateSettings({ ai_provider: p.id }, 'set the assistant model to', p.name)`.
- Disconnect: recommended inline confirm. The first click changes the label to "Confirm disconnect" for 4 seconds. The second click calls `A.disconnectIntegration(g)` and closes the modal.
- Filter and search state live in studio state (`integFilter`, `integQuery`).

## Tokens (design hex to app variable)

| Design value | Variable |
|---|---|
| #111111 text, primary button | `--ink`, `--inv` |
| #2A2A2A | `--ink-2` |
| #666666 secondary text | `--muted` |
| #707070 meta, help, placeholder | `--muted-2` |
| #E6E6E6 borders | `--border` |
| #F0F0F0 dividers | `--line` |
| #FAFAFA inputs, advanced rows | `--surface-2` |
| #FFFFFF cards, modal | `--surface` |
| #1B653B | `--green-ink` |
| #9B1C13 | `--red-ink` |
| #F2F2F2 chips | `--chip` |
| Montserrat 900 | `--font-title` |
| Inter | `--font-sans` |

Radii: card 16px, modal 20px, buttons 14px, inputs and toggles 12px, logo tile 14px (card) and 16px (modal).

New soft fills for pills: add `--green-soft` (light #E6F2EA) and `--red-soft`, with dark-mode values.

## Accessibility

- Card and every control are real `<button>`, `<a href>`, `<input>` and `<label>` elements.
- Dialog: `role="dialog"`, `aria-modal="true"`, `aria-labelledby` on the modal title.
- Advanced toggle: `aria-expanded` plus `aria-controls`.
- Filter tabs: `aria-pressed`. Group with `role="group" aria-label="Filter integrations"`.
- Search input has a visually hidden label.
- Touch targets 44px or more. The "Get a key" link uses min-height 44px with -10px vertical margin to stay compact.
- Text contrast 4.5:1 or better. Muted text never lighter than `--muted-2`.
- Logos are decorative (`alt=""`) because the name sits next to them.

## Responsive

- The grid reflows on its own through `auto-fill`.
- The toolbar wraps: tabs on one row, search full width below.
- The modal goes full width with 16px side gutters. The footer wraps.

## Acceptance checklist

- [ ] 10 cards render in 5 groups with real logos.
- [ ] Filter tabs and search work together. Empty groups hide. The empty state shows when nothing matches.
- [ ] Each modal shows only the quick-add fields from the split table.
- [ ] Advanced is collapsed on open, toggles with the keyboard, and shows the summary line.
- [ ] Saving with Advanced closed keeps the model default and existing optional config values.
- [ ] Save, disconnect, sync, model list and assistant pick still use the existing `A.*` calls.
- [ ] The error state shows "Needs attention" on the card and a banner in the modal.
- [ ] Escape, backdrop and Cancel close the modal. Focus returns to the card.
- [ ] Dark mode renders through the variables. Logo tiles stay white.
- [ ] `pnpm lint` and `pnpm build` pass.

## Out of scope

- OAuth flows
- New providers
- Server, Vault or RLS changes
- Changing the provider descriptions stored in the DB
