# Paste into Claude Code (run from the Sambox-FTGU repo root)

Refactor Workspace Settings > Integrations into a card grid with a quick-add modal and a collapsed Advanced section.

1. Read `HANDOFF.md` in this folder fully before touching code. It is the spec.
2. Read `design/Main.dc.html` for exact styles and the view-model logic in its `renderVals()` script. Treat `.dc.html` files as design reference only. Do not import them.
3. Copy `public/integrations/*` into the repo's `public/integrations/`.
4. Update `lib/integrations/registry.ts` (add `logo`, `powers`), `lib/studio/vals-admin.js` (`integCard`, `integGroups`, new filter, search, modal and advanced state) and `components/studio/StudioView.jsx` (grid, toolbar, modal).
5. Keep every existing `A.*` call, the draft state, the model-list fetching and the busy states exactly as they behave today. UI-only change.
6. Use the existing CSS variables from the tokens table, not raw hex values.
7. Follow `AGENTS.md`. Check the Next.js docs in `node_modules/next/dist/docs/` before using any Next API.
8. Work through the acceptance checklist in `HANDOFF.md`. Run `pnpm lint` and `pnpm build`. Report what passed and anything you changed from the spec.
